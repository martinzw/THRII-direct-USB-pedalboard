#ifndef __SHELL_H__
#define __SHELL_H__

void ble_mesh_shell_init(void);

#endif
