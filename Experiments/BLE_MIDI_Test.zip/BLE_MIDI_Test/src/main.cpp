

/**
 * --------------------------------------------------------
 * This example shows how to use client MidiBLE
 * Client BLEMIDI works in a similar way Server (Common) BLEMIDI, but with some exception.
 * 
 * The most important exception is read() method. This function works as usual, but 
 * now it manages machine-states BLE connection too. The
 * read() function must be called several times continuously in order to scan BLE device
 * and connect with the server. In this example, read() is called in a "multitask function of 
 * FreeRTOS", but it can be called in loop() function as usual.
 * 
 * Some BLEMIDI_CREATE_INSTANCE() are added in MidiBLE-Client to be able to choose a specific server to connect
 * or to connect to the first server which has the MIDI characteristic. You can choose the server by typing in the name field
 * the name of the server or the BLE address of the server. If you want to connect 
 * to the first MIDI server BLE found by the device, you just have to set the name field empty ("").
 * 
 * FOR ADVANCED USERS: Other advanced BLE configurations can be changed in hardware/BLEMIDI_Client_ESP32.h
 * #defines in the head of the file (IMPORTANT: Only the first user defines must be modified). These configurations
 * are related to security (password, pairing and securityCallback()), communication params, the device name 
 * and other stuffs. Modify defines at your own risk.
 * 
 * 
 * 
 * @auth RobertoHE 
 * --------------------------------------------------------
 */

#include <Arduino.h>
#include <BLEMIDI_Transport.h>

#include <hardware/BLEMIDI_Client_ESP32.h>

//#include <hardware/BLEMIDI_ESP32_NimBLE.h>
//#include <hardware/BLEMIDI_ESP32.h>
//#include <hardware/BLEMIDI_nRF52.h>
//#include <hardware/BLEMIDI_ArduinoBLE.h>

byte IDENTITY_REQUEST[]  = { 0xF0, 0x7E, 0x7F, 0x06, 0x01, 0xF7 };

byte VERSION_REQUEST[]  = { 0xF0, // Request THR Amp version
                            0x00, 0x01, 0x0C, // Line6 
                            0x24, // THRII
                            0x02, 0x4D, // THR30IIWireless
                            0x00, // A or B
                            0x00, 0x00, 0x00, 0x07,  //
                            0x00, // 1st bitbucket
                            0x01, 0x00, 0x00, 0x00, // OP
                            0x00, 0x00, 0x00, // FB
                            0x00, // 2nd bitbucket
                            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // Type?
                            0xF7}; 

byte HEADER[]  = { 0xF0, 
                   0x00, 0x01, 0x0C, // Line6 
                   0x24, // THRII
                   0x02, 0x4D, // THR30IIWireless
                   0x00, // A or B
                   0x01, 0x00, 0x00, 
                   0x07, 
                   0x00, 0x04, 0x00, 0x00, 
                   0x00, 0x04, 0x00, 
                   0x00,
                   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                   0xF7}; 

byte MAGIC_KEY[]  = { 0xF0, 
                      0x00, 0x01, 0x0C, // Line6 
                      0x24, // THRII
                      0x02, 0x4D, // THR30IIWireless
                      0x00, // A or B
                      0x02, 0x00, 0x00, 
                      0x03, 
                      0x28, 0x72, 0x4D, 0x54, // Magic key for 1.4.4.0.a
                      0x00, 0x00, 0x00,
                      0xF7};

//BLEMIDI_CREATE_DEFAULT_INSTANCE(); //Connect to first server found

//BLEMIDI_CREATE_INSTANCE("",MIDI)                  //Connect to the first server found
BLEMIDI_CREATE_INSTANCE("cb:81:f4:6b:1d:23",MIDI)   //Connect to a specific BLE address server  (your personal THR30II!)
//BLEMIDI_CREATE_INSTANCE("LE_THRII",MIDI)          //Connect to a specific name server

#ifndef LED_BUILTIN
#define LED_BUILTIN 2 //modify for match with yout board
#endif

void ReadCB(void *parameter);       //Continuos Read function (See FreeRTOS multitasks)

unsigned long t0 = millis();
bool isConnected = false;
bool isIdentitySent =false;    


/**
 * -----------------------------------------------------------------------------
 * When BLE is connected, LED will turn on (indicating that connection was successful)
 * When receiving a NoteOn, LED will go out, on NoteOff, light comes back on.
 * This is an easy and conveniant way to show that the connection is alive and working.
 * -----------------------------------------------------------------------------
*/
void setup()
{
  Serial.begin(115200);
  

  BLEMIDI.setHandleConnected([]()
                             {
                               Serial.println("---------CONNECTED---------");
                               isConnected = true;
                               isIdentitySent = false;
                               digitalWrite(LED_BUILTIN, HIGH);
                             });

  BLEMIDI.setHandleDisconnected([]()
                                {
                                  Serial.println("---------NOT CONNECTED---------");
                                  isConnected = false;
                                  digitalWrite(LED_BUILTIN, LOW);
                                });

  MIDI.setHandleSystemExclusive([] (byte* data, unsigned length) 
  {
    Serial.print(F("SYSEX: ("));
    Serial.print(length);
    Serial.print(F(" bytes) "));
    for (uint16_t i = 0; i < length; i++)
    {
        Serial.print(data[i], HEX);
        Serial.print(" ");
    }
    Serial.println();
  } );

  MIDI.setHandleError([] (int8_t data) 
  {
    Serial.print(F("ERROR: ("));
    Serial.print(data);
    Serial.println(" )");
  } );

    pinMode(LED_BUILTIN, OUTPUT);
    digitalWrite(LED_BUILTIN, LOW);
    
    MIDI.begin(MIDI_CHANNEL_OMNI);
}

// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
void loop()
{
    MIDI.read(MIDI_CHANNEL_OMNI);  

    if (isConnected && !isIdentitySent &&(millis() - t0) > 10000)
    {
        t0 = millis();
        Serial.println(F("Send IDENTITY_REQUEST")); 
        MIDI.sendSysEx(sizeof(IDENTITY_REQUEST),IDENTITY_REQUEST,true);  //"true" for F0 and F7 are contained in Message-Array
        
        Serial.println("Sending VERSION_REQUEST"); 
        MIDI.sendSysEx(sizeof(VERSION_REQUEST),VERSION_REQUEST,true);//"true" for F0 and F7 are contained in Message-Array

        Serial.println("Sending HEADER"); 
        MIDI.sendSysEx(sizeof(HEADER),HEADER,true);//"true" for F0 and F7 are contained in Message-Array

        Serial.println("Sending MAGIC_KEY"); 
        MIDI.sendSysEx(sizeof(MAGIC_KEY),MAGIC_KEY,true);//"true" for F0 and F7 are contained in Message-Array

        isIdentitySent =true;
        Serial.println(F("Now waiting for answer!"));
        //vTaskDelay(250/portTICK_PERIOD_MS);
    }

    
}
